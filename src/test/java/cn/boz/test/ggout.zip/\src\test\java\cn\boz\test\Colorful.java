package cn.boz.test;

import com.intellij.openapi.progress.util.ColorProgressBar;

import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Colorful {

    public static void main(String[] args) {
        JFrame frame = new JFrame("ColorProgressBar Test");
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        frame.setSize(800, 600);
        frame.setLocation(0, 0);
        Container contentPane = frame.getContentPane();
        contentPane.setLayout(new BorderLayout());
        final ColorProgressBar colorProgressBar = new ColorProgressBar();
        colorProgressBar.setFraction(0.5D);
        colorProgressBar.setIndeterminate(true);
        contentPane.add(colorProgressBar, "North");
        frame.setVisible(true);
        JButton b = new JButton("X");
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                colorProgressBar.setFraction(1.0D);
            }
        });
        contentPane.add(b, "South");
    }
}
